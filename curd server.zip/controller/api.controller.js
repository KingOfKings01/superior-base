import prisma from "../lib/prisma.js";

export const createRecord = async (req, res) => {
  try {
    const collectionName = req.params.collection;

    let collection = await prisma.collection.findUnique({
      where: {
        userId_name: {
          userId: req.user.id,
          name: collectionName
        }
      }
    });

    if (!collection) {
      collection = await prisma.collection.create({
        data: {
          name: collectionName,
          userId: req.user.id
        }
      });
    }

    const record = await prisma.record.create({
      data: {
        data: req.body,
        collectionId: collection.id
      }
    });

    return res.status(201).json(record);
  } catch (error) {
    console.error("Create record error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const getRecords = async (req, res) => {
  try {
    const collection = await prisma.collection.findUnique({
      where: {
        userId_name: {
          userId: req.user.id,
          name: req.params.collection
        }
      },
      include: {
        records: true
      }
    });

    if (!collection) {
      return res.json([]);
    }

    // 1. Flatten the inner "data" JSON column into the main object body
    const flattenedRecords = collection.records.map(record => {
      return {
        id: record.id,
        collectionId: record.collectionId,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
        ...record.data // Lifts "price" and "title" out of the inner data object
      };
    });

    // 2. Return the clean, flattened array
    return res.json(flattenedRecords);
  } catch (error) {
    console.error("Get records error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};


export const getRecord = async (req, res) => {
  try {
    const record = await prisma.record.findFirst({
      where: {
        id: req.params.id, // Corrected: Removed Number() casting since IDs are UUID Strings
        collection: {
          userId: req.user.id,
          name: req.params.collection
        }
      }
    });

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    return res.json(record);
  } catch (error) {
    console.error("Get record error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const updateRecord = async (req, res) => {
  try {
    const record = await prisma.record.findFirst({
      where: {
        id: req.params.id, // Corrected: Removed Number() casting
        collection: {
          userId: req.user.id,
          name: req.params.collection
        }
      }
    });

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    const updated = await prisma.record.update({
      where: { id: record.id },
      data: {
        data: req.body
      }
    });

    return res.json(updated);
  } catch (error) {
    console.error("Update record error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const deleteRecord = async (req, res) => {
  try {
    const record = await prisma.record.findFirst({
      where: {
        id: req.params.id, // Corrected: Removed Number() casting
        collection: {
          userId: req.user.id,
          name: req.params.collection
        }
      }
    });

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    await prisma.record.delete({
      where: { id: record.id }
    });

    return res.json({ message: "Record deleted" });
  } catch (error) {
    console.error("Delete record error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
