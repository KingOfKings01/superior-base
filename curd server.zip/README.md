npx prisma migrate dev --name init

"username": "Asif",
  "password": "abc"

{
  "message": "Registered successfully",
  "username": "Asif",
  "apiKey": "3b1e5be0a97179c27e1f6b8d76c8984bc0a5a09c"
}