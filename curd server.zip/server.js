import dotenv from "dotenv"
dotenv.config()
import express from "express";
import cors from "cors";

import path from "path";
import { fileURLToPath } from "url";

import userRouter from "./routers/user.router.js";
import apiRouter from "./routers/api.router.js";

const app = express();

app.use(cors());
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use("/user", userRouter);
app.use("/api", apiRouter);

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "docs.html"));
});

app.listen(3000, "192.168.0.201" ,() => {
  console.log("Server running on http://192.168.0.201:3000");
});
